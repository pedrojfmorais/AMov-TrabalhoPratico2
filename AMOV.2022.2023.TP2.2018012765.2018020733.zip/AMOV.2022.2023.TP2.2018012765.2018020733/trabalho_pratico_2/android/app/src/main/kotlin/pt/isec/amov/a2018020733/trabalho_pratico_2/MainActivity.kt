package pt.isec.amov.a2018020733.trabalho_pratico_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
